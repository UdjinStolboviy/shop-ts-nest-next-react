import { createSelectOption } from './common'

export const categoriesOptions = [
  'Сначала дешевые',
  'Сначала дорогие',
  'По популярности',
].map(createSelectOption)
