export enum HTTPStatus {
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
}
