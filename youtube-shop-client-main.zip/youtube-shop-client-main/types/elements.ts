import { CustomArrowProps } from 'react-slick'

export interface IBrandsSliderArrow extends CustomArrowProps {
  modeClass: string
}
